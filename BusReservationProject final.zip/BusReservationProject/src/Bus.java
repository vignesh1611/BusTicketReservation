import java.util.Date;

public class Bus {

	private int busNo;
	private String ac;
	private int capacity;
	private Date date;
	private Double fair;
	private String destination;

	public Bus() {

	}

	public int getBusNo() {
		return busNo;
	}

	public void setBusNo(int busNo) {
		this.busNo = busNo;
	}

	public String getAc() {
		return ac;
	}

	public void setAc(String ac) {
		this.ac = ac;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Double getFair() {
		return fair;
	}

	public void setFair(double fair) {
		this.fair = fair;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Bus(int busNo, String ac, int capacity, Date date, Double fair, String destination) {
		super();
		this.busNo = busNo;
		this.ac = ac;
		this.capacity = capacity;
		this.date = date;
		this.fair = fair;
		this.destination = destination;
	}

	@Override
	public String toString() {
		return "Bus [busNo=" + busNo + ", ac=" + ac + ", capacity=" + capacity + ", date=" + date + ", fair=" + fair
				+ ", destination=" + destination + "]";
	}

}