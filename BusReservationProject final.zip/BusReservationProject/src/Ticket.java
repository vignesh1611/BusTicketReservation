
public class Ticket {
	String passengerName;
	int age;
	int pId;
	int busNo;
	String date;
	double fair;

	public Ticket() {

	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getpId() {
		return pId;
	}

	public void setpId(int pId) {
		this.pId = pId;
	}

	public int getBusNo() {
		return busNo;
	}

	public void setBusNo(int busNo) {
		this.busNo = busNo;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public double getFair() {
		return fair;
	}

	public void setFair(double fair) {
		this.fair = fair;
	}

	@Override
	public String toString() {
		return "Ticket [passengerName=" + passengerName + ", age=" + age + ", pId=" + pId + ", busNo=" + busNo
				+ ", date=" + date + ", fair=" + fair + "]";
	}

}
