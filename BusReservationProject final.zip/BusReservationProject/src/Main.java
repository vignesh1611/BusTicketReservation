import java.sql.SQLException;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws SQLException, ParseException {

		int userInput, loginInput = 0, adminInput;

		char ch, ch1 = 'y', ch3;

		Admin admin = new Admin();

		Login login = new Login();
		Scanner scan = new Scanner(System.in);

		do {

			System.out.println("\t\tWelcome to EduBridge travels");
			System.out.println("\t\t\t1. Admin" + "\n\t\t\t2. User");
			userInput = scan.nextInt();
			do {
				switch (userInput) {

				case 1:
					System.out.println("\t\t WELCOME TO ADMIN PAGE");
					System.out.println("\t\t\t1. Sign up" + "\n\t\t\t2. Sign In" + "\n\t\t\t3. Home Page");
					loginInput = scan.nextInt();
					switch (loginInput) {
					case 1:
						System.out.println("\t\t WELCOME TO SIGN UP PAGE");
						login.adminSignUp();
						break;
					case 2:
						System.out.println("\t\t WELCOME TO SIGN IN PAGE");

						System.out.println("Enter the User Name : ");
						String UserName = scan.next();
						System.out.println("Enter the Password : ");
						int PassWord = scan.nextInt();
						if (login.adminsignIn(UserName, PassWord)) {
							System.out.println("Login successfull");
							do {
								System.out.println("1. ADD");
								System.out.println("2. DISPLAY");
								System.out.println("3. UPDATE");
								System.out.println("4. DELETE");
								System.out.println("5. VIEW USER DETAILS");
								System.out.println("Enter the choice : ");
								adminInput = scan.nextInt();

								switch (adminInput) {

								case 1:

									admin.add();
									break;
								case 2:
									admin.display();
									break;
								case 3:

									System.out.println("1. Update Bus capacity \n 2. Update Bus Fair");
									int updateOpt = scan.nextInt();
									if (updateOpt == 1) {
										System.out.println("Enter the Bus No: ");
										int busno = scan.nextInt();
										System.out.println("Enter the date(yyyy-MM-dd) : ");
										String date = scan.next();
										System.out.println("Enter the Capacity: ");
										int capacities = scan.nextInt();
										admin.updateBus(capacities, busno, date);
									}
									if (updateOpt == 2) {
										System.out.println("Enter the Bus No: ");
										int busno = scan.nextInt();
										System.out.println("Enter the date(yyyy-MM-dd) : ");
										String date = scan.next();
										System.out.println("Enter the Fair: ");
										Double Fair = scan.nextDouble();
										admin.updateBusFair(Fair, busno, date);
									}
									break;
								case 4:
									System.out.println("Enter the Bus No: ");
									int busno = scan.nextInt();
									System.out.println("Enter the date(yyyy-MM-dd) : ");
									String date = scan.next();
									admin.deleteBus(busno, date);
									break;
								case 5:
									admin.viewUserDetails();
									break;
								default:
									System.out.println("Enter the Valid Option");
								}
								System.out.println("IF YOU WANT TO CONTINUE AS ADMIN MENU (Y/N)");
								ch = scan.next().charAt(0);
							} while (ch == 'y' || ch == 'Y');
							break;
						}
					}
					break;

				case 2:
					System.out.println("\t\t WELCOME TO USER PAGE");
					System.out.println("\t\t\t1. Sign up" + "\n\t\t\t2. Sign In" + "\n\t\t\t3. Home Page");
					loginInput = scan.nextInt();
					switch (loginInput) {
					case 1:
						System.out.println("\t\t WELCOME TO SIGNUP PAGE");
						login.usersignUp();
						break;
					case 2:
						System.out.println("\t\t WELCOME TO SIGNIN PAGE");

						System.out.println("Enter the User Name : ");
						String UserName = scan.next();
						System.out.println("Enter the Password : ");
						int PassWord = scan.nextInt();
						if (login.usersignIn(UserName, PassWord)) {
							System.out.println("Login successfull");

							do {
								System.out.println(
										"1. VIEW BUSES " + "\n2. BOOKINGS " + "\n3. CANCELLATION" + "\n4. VIEW TICKET");
								userInput = scan.nextInt();
								switch (userInput) {
								case 1:
									admin.display();
									break;
								case 2:
									System.out.println("Enter the no of tickets need to book");
									int noOfTickets = scan.nextInt();
									int ticketbooked = 0;
									do {
										admin.bookings();
										ticketbooked++;

									} while (ticketbooked < noOfTickets);
									break;
								case 3:
									admin.cancellation();
									break;
								case 4:
									int p_id;
									System.out.println("Enter the Passenger Id : ");
									p_id = scan.nextInt();
									admin.viewTicket(p_id);
									break;
								}
								System.out.println("Continue to User Page [y/n]");
								ch3 = scan.next().charAt(0);
							} while (ch3 == 'y' || ch3 == 'Y');
						} else {
							System.out.println("Login Failed");
						}
						break;
					}
					break;
				}
				System.out.println("Continue to Login Page [Y/N]");
				ch1 = scan.next().charAt(0);

			} while (ch1 == 'y' || ch1 == 'Y');
			System.out.println("Continue to Home Page [Y/N]");
			ch1 = scan.next().charAt(0);
		} while (ch1 == 'y' || ch1 == 'Y');
	}
}